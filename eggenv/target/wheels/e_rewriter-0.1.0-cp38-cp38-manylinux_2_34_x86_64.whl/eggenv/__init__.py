from .eggenv import *

__doc__ = eggenv.__doc__
if hasattr(eggenv, "__all__"):
    __all__ = eggenv.__all__